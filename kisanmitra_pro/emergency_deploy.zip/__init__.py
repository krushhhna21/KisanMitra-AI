"""KisanMitra application package."""
